package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.security.PinManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Glass Calculator", appName)
    }

    @Test
    fun `test pin manager set and verify`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val pinManager = PinManager(context)
        assertFalse(pinManager.isPinSet())

        pinManager.setPin("1357")
        assertTrue(pinManager.isPinSet())
        assertTrue(pinManager.verifyPin("1357"))
        assertFalse(pinManager.verifyPin("9999"))
        assertFalse(pinManager.verifyPin("135"))
    }
}
