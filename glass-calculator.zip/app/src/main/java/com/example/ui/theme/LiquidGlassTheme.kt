package com.example.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

data class LiquidGlassColors(
    val id: String,
    val name: String,
    val isDark: Boolean,
    val backgroundBrush: Brush,
    val glassSurface: Color,
    val glassSurfaceElevated: Color,
    val glassBorder: Brush,
    val glassBorderSubtle: Brush,
    val accentPrimary: Color,
    val accentSecondary: Color,
    val accentGradient: Brush,
    val textPrimary: Color,
    val textSecondary: Color,
    val keyNumberBg: Color,
    val keyOperatorBg: Color,
    val keyActionBg: Color,
    val keyEqualsBrush: Brush
)

val ObsidianCyanTheme = LiquidGlassColors(
    id = "obsidian_cyan",
    name = "Obsidian Cyan",
    isDark = true,
    backgroundBrush = Brush.verticalGradient(
        colors = listOf(Color(0xFF090D16), Color(0xFF0E1626), Color(0xFF070B12))
    ),
    glassSurface = Color(0x24243B55),
    glassSurfaceElevated = Color(0x382B4666),
    glassBorder = Brush.linearGradient(
        colors = listOf(Color(0x6000F2FE), Color(0x204FACFE), Color(0x10FFFFFF))
    ),
    glassBorderSubtle = Brush.linearGradient(
        colors = listOf(Color(0x30FFFFFF), Color(0x0DFFFFFF))
    ),
    accentPrimary = Color(0xFF00F2FE),
    accentSecondary = Color(0xFF4FACFE),
    accentGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF00F2FE), Color(0xFF4FACFE))
    ),
    textPrimary = Color(0xFFF1F5F9),
    textSecondary = Color(0xFF94A3B8),
    keyNumberBg = Color(0x20334155),
    keyOperatorBg = Color(0x300284C7),
    keyActionBg = Color(0x2564748B),
    keyEqualsBrush = Brush.linearGradient(
        colors = listOf(Color(0xFF00C6FF), Color(0xFF0072FF))
    )
)

val AmethystVioletTheme = LiquidGlassColors(
    id = "amethyst_violet",
    name = "Amethyst Violet",
    isDark = true,
    backgroundBrush = Brush.verticalGradient(
        colors = listOf(Color(0xFF0D0816), Color(0xFF180F29), Color(0xFF0A0612))
    ),
    glassSurface = Color(0x263C1E5C),
    glassSurfaceElevated = Color(0x3B4E2677),
    glassBorder = Brush.linearGradient(
        colors = listOf(Color(0x60C084FC), Color(0x20F472B6), Color(0x10FFFFFF))
    ),
    glassBorderSubtle = Brush.linearGradient(
        colors = listOf(Color(0x30FFFFFF), Color(0x0DFFFFFF))
    ),
    accentPrimary = Color(0xFFC084FC),
    accentSecondary = Color(0xFFF472B6),
    accentGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFFB026FF), Color(0xFFF472B6))
    ),
    textPrimary = Color(0xFFFAF5FF),
    textSecondary = Color(0xFFA8A29E),
    keyNumberBg = Color(0x204A2060),
    keyOperatorBg = Color(0x357E22CE),
    keyActionBg = Color(0x25701A75),
    keyEqualsBrush = Brush.linearGradient(
        colors = listOf(Color(0xFFB026FF), Color(0xFF7928CA))
    )
)

val EmeraldAuroraTheme = LiquidGlassColors(
    id = "emerald_aurora",
    name = "Emerald Aurora",
    isDark = true,
    backgroundBrush = Brush.verticalGradient(
        colors = listOf(Color(0xFF061412), Color(0xFF0C241E), Color(0xFF050E0C))
    ),
    glassSurface = Color(0x26134E48),
    glassSurfaceElevated = Color(0x38115E59),
    glassBorder = Brush.linearGradient(
        colors = listOf(Color(0x6034D399), Color(0x2010B981), Color(0x10FFFFFF))
    ),
    glassBorderSubtle = Brush.linearGradient(
        colors = listOf(Color(0x30FFFFFF), Color(0x0DFFFFFF))
    ),
    accentPrimary = Color(0xFF34D399),
    accentSecondary = Color(0xFF10B981),
    accentGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF34D399), Color(0xFF059669))
    ),
    textPrimary = Color(0xFFF0FDF4),
    textSecondary = Color(0xFF94A3B8),
    keyNumberBg = Color(0x20134E48),
    keyOperatorBg = Color(0x350F766E),
    keyActionBg = Color(0x251E3A3A),
    keyEqualsBrush = Brush.linearGradient(
        colors = listOf(Color(0xFF10B981), Color(0xFF047857))
    )
)

val CrystalLightTheme = LiquidGlassColors(
    id = "crystal_light",
    name = "Frosted Crystal",
    isDark = false,
    backgroundBrush = Brush.verticalGradient(
        colors = listOf(Color(0xFFE2E8F0), Color(0xFFEDF2F7), Color(0xFFF8FAFC))
    ),
    glassSurface = Color(0x60FFFFFF),
    glassSurfaceElevated = Color(0x80FFFFFF),
    glassBorder = Brush.linearGradient(
        colors = listOf(Color(0x80FFFFFF), Color(0x4038BDF8), Color(0x20CBD5E1))
    ),
    glassBorderSubtle = Brush.linearGradient(
        colors = listOf(Color(0x60FFFFFF), Color(0x30CBD5E1))
    ),
    accentPrimary = Color(0xFF0284C7),
    accentSecondary = Color(0xFF0EA5E9),
    accentGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF0284C7), Color(0xFF38BDF8))
    ),
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF475569),
    keyNumberBg = Color(0x50FFFFFF),
    keyOperatorBg = Color(0x40BAE6FD),
    keyActionBg = Color(0x40E2E8F0),
    keyEqualsBrush = Brush.linearGradient(
        colors = listOf(Color(0xFF0284C7), Color(0xFF0EA5E9))
    )
)

val AvailableThemes = listOf(
    ObsidianCyanTheme,
    AmethystVioletTheme,
    EmeraldAuroraTheme,
    CrystalLightTheme
)

val LocalLiquidGlass = staticCompositionLocalOf { ObsidianCyanTheme }

object LiquidGlassTheme {
    val colors: LiquidGlassColors
        @Composable
        @ReadOnlyComposable
        get() = LocalLiquidGlass.current
}

@Composable
fun LiquidGlassAppTheme(
    themeId: String = "obsidian_cyan",
    content: @Composable () -> Unit
) {
    val selected = AvailableThemes.find { it.id == themeId } ?: ObsidianCyanTheme

    val m3Scheme = if (selected.isDark) {
        darkColorScheme(
            primary = selected.accentPrimary,
            secondary = selected.accentSecondary,
            background = Color(0xFF0A0E17),
            surface = Color(0xFF131B2A),
            onPrimary = Color.Black,
            onSecondary = Color.Black,
            onBackground = selected.textPrimary,
            onSurface = selected.textPrimary
        )
    } else {
        lightColorScheme(
            primary = selected.accentPrimary,
            secondary = selected.accentSecondary,
            background = Color(0xFFF1F5F9),
            surface = Color.White,
            onPrimary = Color.White,
            onSecondary = Color.White,
            onBackground = selected.textPrimary,
            onSurface = selected.textPrimary
        )
    }

    CompositionLocalProvider(LocalLiquidGlass provides selected) {
        MaterialTheme(
            colorScheme = m3Scheme,
            content = content
        )
    }
}
