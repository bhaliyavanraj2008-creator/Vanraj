package com.example.ui.vault

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.theme.AvailableThemes
import com.example.ui.theme.LiquidGlassTheme
import java.util.Locale

@Composable
fun SettingsScreen(
    viewModel: VaultViewModel,
    onLockNow: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val stats by viewModel.storageStats.collectAsState()
    val theme = LiquidGlassTheme.colors

    var oldPinInput by remember { mutableStateOf("") }
    var newPinInput by remember { mutableStateOf("") }
    var confirmPinInput by remember { mutableStateOf("") }
    var pinErrorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .padding(bottom = 100.dp)
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Vault Settings",
            color = theme.textPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )

        // 1. Security & Authentication Section
        SettingsSectionHeader(title = "Security & PIN", icon = Icons.Default.Security)

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Change PIN item
                SettingsClickableRow(
                    title = "Change Secret PIN",
                    subtitle = "Update your calculator unlock code",
                    icon = Icons.Default.Key,
                    onClick = {
                        oldPinInput = ""
                        newPinInput = ""
                        confirmPinInput = ""
                        pinErrorMessage = null
                        viewModel.setShowPinChangeDialog(true)
                    },
                    testTag = "change_pin_row"
                )

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp),
                    color = Color.White.copy(0.08f)
                )

                // Biometric Toggle item
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(theme.accentPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = theme.accentPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Biometric Unlock",
                                color = theme.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (uiState.isBiometricAvailable) "Use fingerprint or face recognition" else "Biometrics not available on device",
                                color = theme.textSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Switch(
                        checked = uiState.isBiometricEnabled,
                        onCheckedChange = { viewModel.toggleBiometric(it) },
                        enabled = uiState.isBiometricAvailable,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = theme.accentPrimary
                        ),
                        modifier = Modifier.testTag("biometric_switch")
                    )
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp),
                    color = Color.White.copy(0.08f)
                )

                // Auto-lock Timeout selection
                Text(
                    text = "Automatic Background Lock",
                    color = theme.textPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Text(
                    text = "Lock the vault when switching apps or locking the screen",
                    color = theme.textSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                val timeoutOptions = listOf(
                    0L to "Immediate",
                    30000L to "30 sec",
                    60000L to "1 min",
                    300000L to "5 min"
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    timeoutOptions.forEach { (timeMs, label) ->
                        val isSelected = uiState.autoLockTimeoutMs == timeMs
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) theme.accentPrimary.copy(0.2f) else theme.glassSurfaceElevated)
                                .border(
                                    1.dp,
                                    if (isSelected) theme.accentPrimary else Color.Transparent,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { viewModel.updateAutoLockTimeout(timeMs) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) theme.accentPrimary else theme.textSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // 2. App Icon Stealth & Recovery
        SettingsSectionHeader(title = "App Icon & Stealth", icon = Icons.Default.VisibilityOff)

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(theme.accentSecondary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = theme.accentSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Hide App Launcher Icon",
                                color = theme.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Remove icon from home screen where supported",
                                color = theme.textSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Switch(
                        checked = uiState.isAppIconHidden,
                        onCheckedChange = { viewModel.setAppIconHidden(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = theme.accentSecondary
                        ),
                        modifier = Modifier.testTag("app_icon_switch")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                GlassButton(
                    text = "View Recovery Instructions",
                    icon = Icons.Default.HelpOutline,
                    isPrimary = false,
                    onClick = { viewModel.setShowIconRecoveryDialog(true) },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "recovery_instructions_btn"
                )
            }
        }

        // 3. Liquid Glass Themes
        SettingsSectionHeader(title = "Liquid Glass Themes", icon = Icons.Default.ColorLens)

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AvailableThemes.forEach { appTheme ->
                    val isSelected = uiState.currentThemeId == appTheme.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) theme.accentPrimary.copy(alpha = 0.15f) else Color.Transparent)
                            .border(
                                1.dp,
                                if (isSelected) theme.accentPrimary else Color.White.copy(0.06f),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.updateTheme(appTheme.id) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(appTheme.accentPrimary)
                                    .border(1.dp, Color.White.copy(0.4f), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = appTheme.name,
                                color = theme.textPrimary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        }

                        if (isSelected) {
                            Text(
                                text = "Active",
                                color = theme.accentPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 4. Storage Breakdown
        SettingsSectionHeader(title = "Encrypted Storage", icon = Icons.Default.PieChart)

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StorageRow(
                    label = "Private Photos",
                    sizeText = formatBytes(stats.photoBytes),
                    color = theme.accentPrimary
                )
                StorageRow(
                    label = "Private Videos",
                    sizeText = formatBytes(stats.videoBytes),
                    color = theme.accentSecondary
                )
                StorageRow(
                    label = "Available Device Space",
                    sizeText = formatBytes(stats.freeDeviceBytes),
                    color = Color(0xFF10B981)
                )
                StorageRow(
                    label = "Total Vault Media",
                    sizeText = "${stats.totalItems} items",
                    color = theme.textSecondary
                )
            }
        }

        // 5. Security & Privacy Notice Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = theme.glassSurfaceElevated
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = theme.accentPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Zero-Knowledge On-Device Storage",
                        color = theme.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "All photos and videos are encrypted with hardware-backed AES-256-GCM. Your files never leave your device. Make sure you remember your secret PIN; encrypted data cannot be recovered without it.",
                        color = theme.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Lock Vault Button
        GlassButton(
            text = "Lock Vault Now",
            icon = Icons.Default.Lock,
            onClick = onLockNow,
            modifier = Modifier.fillMaxWidth(),
            testTag = "settings_lock_now_btn"
        )
    }

    // Change PIN Dialog
    if (uiState.showPinChangeDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowPinChangeDialog(false) },
            title = { Text("Change Vault PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = oldPinInput,
                        onValueChange = { oldPinInput = it },
                        label = { Text("Current PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPinInput,
                        onValueChange = { newPinInput = it },
                        label = { Text("New PIN (4-8 digits)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = confirmPinInput,
                        onValueChange = { confirmPinInput = it },
                        label = { Text("Confirm New PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    pinErrorMessage?.let { err ->
                        Text(
                            text = err,
                            color = Color(0xFFFF5252),
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newPinInput.length !in 4..8 || !newPinInput.all { it.isDigit() }) {
                        pinErrorMessage = "New PIN must be 4 to 8 digits."
                        return@TextButton
                    }
                    if (newPinInput != confirmPinInput) {
                        pinErrorMessage = "New PINs do not match."
                        return@TextButton
                    }
                    val success = viewModel.changePin(oldPinInput, newPinInput)
                    if (!success) {
                        pinErrorMessage = "Current PIN is incorrect."
                    }
                }) {
                    Text("Save PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowPinChangeDialog(false) }) {
                    Text("Cancel")
                }
            }
        )
    }

    // App Icon Recovery Instructions Modal
    if (uiState.showIconRecoveryDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowIconRecoveryDialog(false) },
            title = { Text("App Icon Visibility & Recovery") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "How to open the app if the icon is hidden:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text("1. Open your phone's Settings app.")
                    Text("2. Navigate to 'Apps' or 'Manage Apps'.")
                    Text("3. Find 'Glass Calculator' in the list.")
                    Text("4. Tap 'Open' to launch the app directly.")
                    Text("5. You can restore the home screen icon anytime from this Settings page.")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Note: Hiding the icon does NOT remove the app from Android Settings, and never prevents you from locating or uninstalling it.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.setShowIconRecoveryDialog(false) }) {
                    Text("Understood")
                }
            }
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String, icon: ImageVector) {
    val theme = LiquidGlassTheme.colors
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = theme.accentPrimary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            color = theme.textPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
    }
}

@Composable
fun SettingsClickableRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    val theme = LiquidGlassTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(theme.accentPrimary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = theme.accentPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    color = theme.textPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Text(
                    text = subtitle,
                    color = theme.textSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun StorageRow(label: String, sizeText: String, color: Color) {
    val theme = LiquidGlassTheme.colors
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                color = theme.textPrimary,
                fontSize = 13.sp
            )
        }
        Text(
            text = sizeText,
            color = theme.textSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

private fun formatBytes(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024.0) {
        String.format(Locale.US, "%.2f GB", mb / 1024.0)
    } else {
        String.format(Locale.US, "%.1f MB", mb)
    }
}
