package com.example.ui.vault

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MediaType
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassIconButton
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun VaultHomeScreen(
    viewModel: VaultViewModel,
    onLockVault: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val allAlbums by viewModel.albums.collectAsState()
    val theme = LiquidGlassTheme.colors

    val snackbarHostState = remember { SnackbarHostState() }
    var newAlbumNameInput by remember { mutableStateOf("") }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importMediaUris(uris, MediaType.PHOTO)
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importMediaUris(uris, MediaType.VIDEO)
        }
    }

    BackHandler {
        if (uiState.isMultiSelectMode) {
            viewModel.clearSelection()
        } else if (uiState.selectedTab != VaultTab.PHOTOS) {
            viewModel.selectTab(VaultTab.PHOTOS)
        } else {
            onLockVault()
        }
    }

    LaunchedEffect(uiState.infoSnackbarMessage) {
        uiState.infoSnackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissSnackbar()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(theme.backgroundBrush)
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                // Liquid Glass Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(theme.accentGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (theme.isDark) Color(0xFF090D16) else Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Glass Vault",
                                color = theme.textPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Encrypted On-Device",
                                color = theme.accentPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    GlassIconButton(
                        icon = Icons.Default.Lock,
                        onClick = onLockVault,
                        tint = theme.accentPrimary,
                        size = 38.dp,
                        contentDescription = "Lock Vault",
                        testTag = "lock_vault_top_btn"
                    )
                }
            },
            bottomBar = {
                // Floating Liquid Glass Navigation Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(28.dp))
                            .background(theme.glassSurfaceElevated)
                            .border(1.dp, theme.glassBorderSubtle, RoundedCornerShape(28.dp))
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NavTabItem(
                            icon = Icons.Default.Photo,
                            label = "Photos",
                            isSelected = uiState.selectedTab == VaultTab.PHOTOS,
                            onClick = { viewModel.selectTab(VaultTab.PHOTOS) },
                            testTag = "nav_tab_photos"
                        )
                        NavTabItem(
                            icon = Icons.Default.Videocam,
                            label = "Videos",
                            isSelected = uiState.selectedTab == VaultTab.VIDEOS,
                            onClick = { viewModel.selectTab(VaultTab.VIDEOS) },
                            testTag = "nav_tab_videos"
                        )
                        NavTabItem(
                            icon = Icons.Default.Folder,
                            label = "Albums",
                            isSelected = uiState.selectedTab == VaultTab.ALBUMS,
                            onClick = { viewModel.selectTab(VaultTab.ALBUMS) },
                            testTag = "nav_tab_albums"
                        )
                        NavTabItem(
                            icon = Icons.Default.Settings,
                            label = "Settings",
                            isSelected = uiState.selectedTab == VaultTab.SETTINGS,
                            onClick = { viewModel.selectTab(VaultTab.SETTINGS) },
                            testTag = "nav_tab_settings"
                        )
                    }
                }
            },
            floatingActionButton = {
                // FAB for quick importing Photos/Videos
                if (uiState.selectedTab == VaultTab.PHOTOS || uiState.selectedTab == VaultTab.VIDEOS) {
                    FloatingActionButton(
                        onClick = {
                            if (uiState.selectedTab == VaultTab.PHOTOS) {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            } else {
                                videoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            }
                        },
                        containerColor = theme.accentPrimary,
                        contentColor = if (theme.isDark) Color(0xFF090D16) else Color.White,
                        shape = CircleShape,
                        modifier = Modifier
                            .padding(bottom = 72.dp)
                            .testTag("fab_import")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Import",
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                Crossfade(targetState = uiState.selectedTab, label = "tab_fade") { tab ->
                    when (tab) {
                        VaultTab.PHOTOS -> PhotosScreen(viewModel = viewModel)
                        VaultTab.VIDEOS -> VideosScreen(viewModel = viewModel)
                        VaultTab.ALBUMS -> AlbumsScreen(viewModel = viewModel)
                        VaultTab.SETTINGS -> SettingsScreen(viewModel = viewModel, onLockNow = onLockVault)
                    }
                }

                // Import Loading Indicator Overlay
                AnimatedVisibility(
                    visible = uiState.isImporting,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    GlassCard(
                        modifier = Modifier.padding(24.dp),
                        backgroundColor = Color(0xD0101626)
                    ) {
                        Row(
                            modifier = Modifier.padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                color = theme.accentPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = uiState.importProgress.ifEmpty { "Encrypting media securely..." },
                                color = theme.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Overlays: Fullscreen Photo Viewer & Video Player
        uiState.activePhotoItem?.let { photoItem ->
            PhotoDetailViewer(
                item = photoItem,
                bitmap = uiState.activePhotoBitmap,
                onClose = { viewModel.closePhotoDetail() },
                onExport = { viewModel.exportItem(it) },
                onDelete = { viewModel.deleteItem(it) }
            )
        }

        uiState.activeVideoItem?.let { videoItem ->
            VideoPlayerDialog(
                item = videoItem,
                videoFile = uiState.activeVideoFile,
                onClose = { viewModel.closeVideoPlayer() },
                onExport = { viewModel.exportItem(it) },
                onDelete = { viewModel.deleteItem(it) }
            )
        }
    }

    // New Album Dialog
    if (uiState.showNewAlbumDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowNewAlbumDialog(false) },
            title = { Text("Create New Album") },
            text = {
                OutlinedTextField(
                    value = newAlbumNameInput,
                    onValueChange = { newAlbumNameInput = it },
                    label = { Text("Album Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newAlbumNameInput.isNotBlank()) {
                        viewModel.createAlbum(newAlbumNameInput.trim())
                        newAlbumNameInput = ""
                    }
                }) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowNewAlbumDialog(false) }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Move to Album Dialog
    if (uiState.showMoveAlbumDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowMoveAlbumDialog(false) },
            title = { Text("Move Selected to Album") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    allAlbums.forEach { album ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { viewModel.moveSelectedToAlbum(album.name) }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = null,
                                tint = theme.accentPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = album.name,
                                color = theme.textPrimary,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { viewModel.setShowMoveAlbumDialog(false) }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun NavTabItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val theme = LiquidGlassTheme.colors

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) theme.accentPrimary.copy(alpha = 0.2f) else Color.Transparent)
            .border(
                1.dp,
                if (isSelected) theme.accentPrimary.copy(alpha = 0.4f) else Color.Transparent,
                RoundedCornerShape(20.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) theme.accentPrimary else theme.textSecondary,
                modifier = Modifier.size(20.dp)
            )
            if (isSelected) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    color = theme.accentPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
