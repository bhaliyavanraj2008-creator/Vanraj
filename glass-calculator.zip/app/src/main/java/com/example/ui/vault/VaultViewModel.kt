package com.example.ui.vault

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MainActivity
import com.example.data.MediaType
import com.example.data.VaultAlbum
import com.example.data.VaultItem
import com.example.data.VaultRepository
import com.example.security.BiometricHelper
import com.example.security.PinManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class StorageStats(
    val photoBytes: Long = 0L,
    val videoBytes: Long = 0L,
    val freeDeviceBytes: Long = 0L,
    val totalItems: Int = 0
)

data class VaultUiState(
    val selectedTab: VaultTab = VaultTab.PHOTOS,
    val selectedAlbumFilter: String = "All",
    val isMultiSelectMode: Boolean = false,
    val selectedItemIds: Set<String> = emptySet(),
    val isImporting: Boolean = false,
    val importProgress: String = "",
    val activePhotoItem: VaultItem? = null,
    val activePhotoBitmap: Bitmap? = null,
    val activeVideoItem: VaultItem? = null,
    val activeVideoFile: File? = null,
    val infoSnackbarMessage: String? = null,
    val currentThemeId: String = "obsidian_cyan",
    val isBiometricEnabled: Boolean = false,
    val isBiometricAvailable: Boolean = false,
    val autoLockTimeoutMs: Long = 0L,
    val isAppIconHidden: Boolean = false,
    val showPinChangeDialog: Boolean = false,
    val showIconRecoveryDialog: Boolean = false,
    val showNewAlbumDialog: Boolean = false,
    val showMoveAlbumDialog: Boolean = false
)

enum class VaultTab {
    PHOTOS,
    VIDEOS,
    ALBUMS,
    SETTINGS
}

class VaultViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    val repository = VaultRepository(context)
    val pinManager = PinManager(context)

    private val _uiState = MutableStateFlow(
        VaultUiState(
            currentThemeId = pinManager.getSelectedTheme(),
            isBiometricEnabled = pinManager.isBiometricEnabled(),
            isBiometricAvailable = BiometricHelper.isBiometricAvailable(context),
            autoLockTimeoutMs = pinManager.getAutoLockTimeoutMs(),
            isAppIconHidden = pinManager.isAppIconHidden()
        )
    )
    val uiState: StateFlow<VaultUiState> = _uiState.asStateFlow()

    val photos = repository.getItems(MediaType.PHOTO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val videos = repository.getItems(MediaType.VIDEO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val albums = repository.getAllAlbums()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val storageStats: StateFlow<StorageStats> = combine(
        repository.getSizeByType(MediaType.PHOTO),
        repository.getSizeByType(MediaType.VIDEO),
        repository.getCountByType(MediaType.PHOTO),
        repository.getCountByType(MediaType.VIDEO)
    ) { photoBytes, videoBytes, photoCount, videoCount ->
        StorageStats(
            photoBytes = photoBytes ?: 0L,
            videoBytes = videoBytes ?: 0L,
            freeDeviceBytes = repository.getDeviceFreeSpace(),
            totalItems = photoCount + videoCount
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StorageStats())

    fun selectTab(tab: VaultTab) {
        _uiState.value = _uiState.value.copy(
            selectedTab = tab,
            isMultiSelectMode = false,
            selectedItemIds = emptySet()
        )
    }

    fun setAlbumFilter(album: String) {
        _uiState.value = _uiState.value.copy(selectedAlbumFilter = album)
    }

    fun toggleSelection(itemId: String) {
        val current = _uiState.value.selectedItemIds.toMutableSet()
        if (current.contains(itemId)) {
            current.remove(itemId)
        } else {
            current.add(itemId)
        }
        _uiState.value = _uiState.value.copy(
            selectedItemIds = current,
            isMultiSelectMode = current.isNotEmpty()
        )
    }

    fun clearSelection() {
        _uiState.value = _uiState.value.copy(
            isMultiSelectMode = false,
            selectedItemIds = emptySet()
        )
    }

    fun importMediaUris(uris: List<Uri>, type: MediaType) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isImporting = true,
                importProgress = "Encrypting 1 of ${uris.size}..."
            )
            var successCount = 0
            val targetAlbum = if (_uiState.value.selectedAlbumFilter != "All") _uiState.value.selectedAlbumFilter else "Default"

            uris.forEachIndexed { index, uri ->
                _uiState.value = _uiState.value.copy(
                    importProgress = "Encrypting ${index + 1} of ${uris.size}..."
                )
                val result = repository.importMedia(uri, type, targetAlbum)
                if (result.isSuccess) successCount++
            }

            _uiState.value = _uiState.value.copy(
                isImporting = false,
                importProgress = "",
                infoSnackbarMessage = "Successfully imported $successCount ${if (type == MediaType.PHOTO) "photo(s)" else "video(s)"}"
            )
        }
    }

    fun openPhotoDetail(item: VaultItem) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(activePhotoItem = item, activePhotoBitmap = null)
            val bitmap = repository.decryptPhotoToBitmap(item)
            _uiState.value = _uiState.value.copy(activePhotoBitmap = bitmap)
        }
    }

    fun closePhotoDetail() {
        _uiState.value = _uiState.value.copy(activePhotoItem = null, activePhotoBitmap = null)
    }

    fun openVideoPlayer(item: VaultItem) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                activeVideoItem = item,
                activeVideoFile = null,
                isImporting = true,
                importProgress = "Decrypting video for playback..."
            )
            val file = repository.prepareVideoForPlayback(item)
            _uiState.value = _uiState.value.copy(
                activeVideoFile = file,
                isImporting = false,
                importProgress = ""
            )
        }
    }

    fun closeVideoPlayer() {
        _uiState.value = _uiState.value.copy(activeVideoItem = null, activeVideoFile = null)
        repository.clearPlaybackCache()
    }

    fun exportItem(item: VaultItem) {
        viewModelScope.launch {
            val res = repository.exportToGallery(item)
            _uiState.value = _uiState.value.copy(
                infoSnackbarMessage = if (res.isSuccess) "Exported to Gallery successfully" else "Export failed: ${res.exceptionOrNull()?.localizedMessage}"
            )
        }
    }

    fun deleteItem(item: VaultItem) {
        viewModelScope.launch {
            repository.deleteItem(item)
            if (_uiState.value.activePhotoItem?.id == item.id) {
                closePhotoDetail()
            }
            if (_uiState.value.activeVideoItem?.id == item.id) {
                closeVideoPlayer()
            }
            _uiState.value = _uiState.value.copy(
                infoSnackbarMessage = "Item securely deleted from vault"
            )
        }
    }

    fun exportSelectedItems(allItems: List<VaultItem>) {
        val selected = allItems.filter { _uiState.value.selectedItemIds.contains(it.id) }
        viewModelScope.launch {
            var count = 0
            selected.forEach {
                if (repository.exportToGallery(it).isSuccess) count++
            }
            clearSelection()
            _uiState.value = _uiState.value.copy(
                infoSnackbarMessage = "Exported $count item(s) to Gallery"
            )
        }
    }

    fun deleteSelectedItems(allItems: List<VaultItem>) {
        val selected = allItems.filter { _uiState.value.selectedItemIds.contains(it.id) }
        viewModelScope.launch {
            selected.forEach { repository.deleteItem(it) }
            clearSelection()
            _uiState.value = _uiState.value.copy(
                infoSnackbarMessage = "Deleted ${selected.size} item(s)"
            )
        }
    }

    fun moveSelectedToAlbum(albumName: String) {
        viewModelScope.launch {
            _uiState.value.selectedItemIds.forEach { id ->
                repository.moveItemToAlbum(id, albumName)
            }
            clearSelection()
            _uiState.value = _uiState.value.copy(
                showMoveAlbumDialog = false,
                infoSnackbarMessage = "Moved to album '$albumName'"
            )
        }
    }

    fun createAlbum(name: String) {
        viewModelScope.launch {
            repository.createAlbum(name)
            _uiState.value = _uiState.value.copy(
                showNewAlbumDialog = false,
                infoSnackbarMessage = "Album '$name' created"
            )
        }
    }

    fun deleteAlbum(name: String) {
        viewModelScope.launch {
            repository.deleteAlbum(name)
            if (_uiState.value.selectedAlbumFilter == name) {
                _uiState.value = _uiState.value.copy(selectedAlbumFilter = "All")
            }
            _uiState.value = _uiState.value.copy(
                infoSnackbarMessage = "Album '$name' removed"
            )
        }
    }

    fun updateTheme(themeId: String) {
        pinManager.setSelectedTheme(themeId)
        _uiState.value = _uiState.value.copy(currentThemeId = themeId)
    }

    fun toggleBiometric(enabled: Boolean) {
        pinManager.setBiometricEnabled(enabled)
        _uiState.value = _uiState.value.copy(isBiometricEnabled = enabled)
    }

    fun updateAutoLockTimeout(timeoutMs: Long) {
        pinManager.setAutoLockTimeoutMs(timeoutMs)
        _uiState.value = _uiState.value.copy(autoLockTimeoutMs = timeoutMs)
    }

    fun setAppIconHidden(hidden: Boolean) {
        pinManager.setAppIconHidden(hidden)
        _uiState.value = _uiState.value.copy(isAppIconHidden = hidden)

        try {
            val pm = context.packageManager
            val componentName = ComponentName(context, MainActivity::class.java)
            val newState = if (hidden) {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            }
            pm.setComponentEnabledSetting(componentName, newState, PackageManager.DONT_KILL_APP)
        } catch (_: Exception) {}

        if (hidden) {
            _uiState.value = _uiState.value.copy(showIconRecoveryDialog = true)
        }
    }

    fun changePin(oldPin: String, newPin: String): Boolean {
        if (!pinManager.verifyPin(oldPin)) return false
        pinManager.setPin(newPin)
        _uiState.value = _uiState.value.copy(
            showPinChangeDialog = false,
            infoSnackbarMessage = "Secret PIN successfully updated"
        )
        return true
    }

    fun setShowPinChangeDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showPinChangeDialog = show)
    }

    fun setShowIconRecoveryDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showIconRecoveryDialog = show)
    }

    fun setShowNewAlbumDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showNewAlbumDialog = show)
    }

    fun setShowMoveAlbumDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showMoveAlbumDialog = show)
    }

    fun dismissSnackbar() {
        _uiState.value = _uiState.value.copy(infoSnackbarMessage = null)
    }

    fun onAppBackgrounded() {
        repository.clearPlaybackCache()
    }
}
