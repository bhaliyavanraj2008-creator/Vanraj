package com.example.ui.calculator

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.security.BiometricHelper
import com.example.security.PinManager
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

enum class PinSetupStep {
    NOT_IN_SETUP,
    ENTER_NEW_PIN,
    CONFIRM_NEW_PIN
}

data class CalculatorUiState(
    val displayText: String = "0",
    val expressionText: String = "",
    val resultPreview: String = "",
    val isPinSet: Boolean = false,
    val setupStep: PinSetupStep = PinSetupStep.NOT_IN_SETUP,
    val setupPromptMessage: String? = null,
    val isBiometricEnabled: Boolean = false,
    val isBiometricAvailable: Boolean = false,
    val isUnlocked: Boolean = false
)

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    val pinManager = PinManager(context)

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    private val _unlockEvent = MutableSharedFlow<Unit>()
    val unlockEvent: SharedFlow<Unit> = _unlockEvent.asSharedFlow()

    private var currentOperand: String = ""
    private var pendingOperator: String? = null
    private var accumulatedValue: Double? = null
    private var isNewCalculation: Boolean = true
    private var firstEnteredPin: String = ""
    private var rawDigitSequence: StringBuilder = StringBuilder()

    private val numberFormatter = DecimalFormat("#,###.########", DecimalFormatSymbols(Locale.US))

    init {
        refreshState()
    }

    fun refreshState() {
        val pinSet = pinManager.isPinSet()
        val biometricAvail = BiometricHelper.isBiometricAvailable(context)
        val biometricOn = pinManager.isBiometricEnabled() && biometricAvail

        val step = if (!pinSet) PinSetupStep.ENTER_NEW_PIN else PinSetupStep.NOT_IN_SETUP
        val prompt = if (!pinSet) "Enter 4-8 digits and press '=' to set your secret Vault PIN" else null

        _uiState.value = _uiState.value.copy(
            isPinSet = pinSet,
            setupStep = step,
            setupPromptMessage = prompt,
            isBiometricEnabled = biometricOn,
            isBiometricAvailable = biometricAvail
        )
    }

    fun onDigit(digit: String) {
        if (isNewCalculation && pendingOperator == null) {
            currentOperand = digit
            rawDigitSequence.clear()
            isNewCalculation = false
        } else {
            if (currentOperand == "0" && digit != ".") {
                currentOperand = digit
            } else {
                currentOperand += digit
            }
        }
        rawDigitSequence.append(digit)
        updateDisplay()
    }

    fun onDecimal() {
        if (isNewCalculation && pendingOperator == null) {
            currentOperand = "0."
            rawDigitSequence.clear()
            rawDigitSequence.append("0.")
            isNewCalculation = false
        } else if (!currentOperand.contains(".")) {
            if (currentOperand.isEmpty()) {
                currentOperand = "0."
            } else {
                currentOperand += "."
            }
            rawDigitSequence.append(".")
        }
        updateDisplay()
    }

    fun onOperator(op: String) {
        rawDigitSequence.clear()
        val currentVal = currentOperand.toDoubleOrNull()

        if (currentVal != null) {
            if (accumulatedValue != null && pendingOperator != null) {
                accumulatedValue = compute(accumulatedValue!!, currentVal, pendingOperator!!)
            } else {
                accumulatedValue = currentVal
            }
        }

        pendingOperator = op
        currentOperand = ""
        isNewCalculation = false
        _uiState.value = _uiState.value.copy(
            displayText = if (accumulatedValue != null) formatNumber(accumulatedValue!!) else "0",
            expressionText = "${formatNumber(accumulatedValue ?: 0.0)} $op"
        )
    }

    fun onPercentage() {
        val value = currentOperand.toDoubleOrNull() ?: accumulatedValue ?: return
        val percentValue = value / 100.0
        currentOperand = percentValue.toString()
        rawDigitSequence.clear()
        updateDisplay()
    }

    fun onToggleSign() {
        if (currentOperand.isNotEmpty() && currentOperand != "0") {
            currentOperand = if (currentOperand.startsWith("-")) {
                currentOperand.substring(1)
            } else {
                "-$currentOperand"
            }
            updateDisplay()
        }
    }

    fun onBackspace() {
        if (currentOperand.isNotEmpty()) {
            currentOperand = currentOperand.dropLast(1)
            if (rawDigitSequence.isNotEmpty()) {
                rawDigitSequence.deleteCharAt(rawDigitSequence.length - 1)
            }
            if (currentOperand.isEmpty()) {
                currentOperand = "0"
            }
            updateDisplay()
        }
    }

    fun onClear() {
        currentOperand = ""
        pendingOperator = null
        accumulatedValue = null
        isNewCalculation = true
        rawDigitSequence.clear()
        _uiState.value = _uiState.value.copy(
            displayText = "0",
            expressionText = "",
            resultPreview = ""
        )
    }

    fun onEquals() {
        val pinCandidate = if (rawDigitSequence.isNotEmpty()) rawDigitSequence.toString() else currentOperand

        // Check PIN setup flow
        if (!_uiState.value.isPinSet) {
            handlePinSetup(pinCandidate)
            return
        }

        // Check Vault Unlock
        if (pinManager.verifyPin(pinCandidate) || pinManager.verifyPin(currentOperand)) {
            triggerUnlock()
            return
        }

        // If not matching PIN, perform authentic mathematical equals
        val currentVal = currentOperand.toDoubleOrNull()
        if (accumulatedValue != null && pendingOperator != null && currentVal != null) {
            val result = compute(accumulatedValue!!, currentVal, pendingOperator!!)
            val exp = "${formatNumber(accumulatedValue!!)} $pendingOperator ${formatNumber(currentVal)} ="
            accumulatedValue = result
            currentOperand = formatRaw(result)
            pendingOperator = null
            isNewCalculation = true
            rawDigitSequence.clear()

            _uiState.value = _uiState.value.copy(
                displayText = formatNumber(result),
                expressionText = exp
            )
        }
    }

    private fun handlePinSetup(candidate: String) {
        val cleanDigits = candidate.filter { it.isDigit() }
        when (_uiState.value.setupStep) {
            PinSetupStep.ENTER_NEW_PIN -> {
                if (cleanDigits.length in 4..8) {
                    firstEnteredPin = cleanDigits
                    onClear()
                    _uiState.value = _uiState.value.copy(
                        setupStep = PinSetupStep.CONFIRM_NEW_PIN,
                        setupPromptMessage = "Confirm PIN: Re-enter $cleanDigits and press '='"
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        setupPromptMessage = "PIN must be between 4 and 8 digits. Try again."
                    )
                }
            }
            PinSetupStep.CONFIRM_NEW_PIN -> {
                if (cleanDigits == firstEnteredPin) {
                    pinManager.setPin(cleanDigits)
                    _uiState.value = _uiState.value.copy(
                        isPinSet = true,
                        setupStep = PinSetupStep.NOT_IN_SETUP,
                        setupPromptMessage = "Secret PIN created successfully! Vault Unlocked."
                    )
                    triggerUnlock()
                } else {
                    firstEnteredPin = ""
                    onClear()
                    _uiState.value = _uiState.value.copy(
                        setupStep = PinSetupStep.ENTER_NEW_PIN,
                        setupPromptMessage = "PINs did not match. Enter 4-8 digits and press '='"
                    )
                }
            }
            else -> {}
        }
    }

    fun triggerUnlock() {
        _uiState.value = _uiState.value.copy(isUnlocked = true)
        viewModelScope.launch {
            _unlockEvent.emit(Unit)
        }
    }

    fun lockVault() {
        _uiState.value = _uiState.value.copy(isUnlocked = false)
        onClear()
    }

    private fun compute(a: Double, b: Double, op: String): Double {
        return when (op) {
            "+" -> a + b
            "-" -> a - b
            "×" -> a * b
            "÷" -> if (b != 0.0) a / b else Double.NaN
            else -> b
        }
    }

    private fun updateDisplay() {
        val text = if (currentOperand.isEmpty()) "0" else currentOperand
        val formatted = if (text.endsWith(".")) {
            val numPart = text.dropLast(1).toDoubleOrNull()
            if (numPart != null) "${formatNumber(numPart)}." else text
        } else if (text.contains(".")) {
            val parts = text.split(".")
            val intPart = parts[0].toDoubleOrNull()
            if (intPart != null) "${formatNumber(intPart)}.${parts[1]}" else text
        } else {
            val num = text.toDoubleOrNull()
            if (num != null) formatNumber(num) else text
        }

        _uiState.value = _uiState.value.copy(
            displayText = formatted
        )
    }

    private fun formatNumber(value: Double): String {
        return if (value.isNaN()) {
            "Error"
        } else if (value.isInfinite()) {
            "Infinity"
        } else {
            numberFormatter.format(value)
        }
    }

    private fun formatRaw(value: Double): String {
        return if (value % 1.0 == 0.0 && value < Long.MAX_VALUE && value > Long.MIN_VALUE) {
            value.toLong().toString()
        } else {
            value.toString()
        }
    }
}
