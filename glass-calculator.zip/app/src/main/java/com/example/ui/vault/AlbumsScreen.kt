package com.example.ui.vault

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VaultAlbum
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassIconButton
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun AlbumsScreen(
    viewModel: VaultViewModel,
    modifier: Modifier = Modifier
) {
    val albums by viewModel.albums.collectAsState()
    val allPhotos by viewModel.photos.collectAsState()
    val allVideos by viewModel.videos.collectAsState()
    val theme = LiquidGlassTheme.colors

    var albumToDelete by remember { mutableStateOf<VaultAlbum?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("albums_screen")
    ) {
        // Header with "New Album" action
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Albums",
                    color = theme.textPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${albums.size} categories",
                    color = theme.textSecondary,
                    fontSize = 13.sp
                )
            }

            GlassButton(
                text = "New Album",
                icon = Icons.Default.Add,
                onClick = { viewModel.setShowNewAlbumDialog(true) },
                shape = RoundedCornerShape(14.dp),
                testTag = "create_album_btn"
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 150.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(albums, key = { it.name }) { album ->
                val photoCount = allPhotos.count { it.album == album.name }
                val videoCount = allVideos.count { it.album == album.name }

                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    onClick = {
                        viewModel.setAlbumFilter(album.name)
                        viewModel.selectTab(VaultTab.PHOTOS)
                    }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(theme.accentPrimary.copy(alpha = 0.15f))
                                    .border(1.dp, theme.accentPrimary.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = null,
                                    tint = theme.accentPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            if (!album.isSystem && album.name != "Default") {
                                GlassIconButton(
                                    icon = Icons.Default.Delete,
                                    onClick = { albumToDelete = album },
                                    tint = Color(0xFFFF5252),
                                    size = 32.dp,
                                    contentDescription = "Delete Album"
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = album.name,
                            color = theme.textPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            maxLines = 1
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Photo,
                                contentDescription = null,
                                tint = theme.textSecondary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "$photoCount",
                                color = theme.textSecondary,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                tint = theme.textSecondary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "$videoCount",
                                color = theme.textSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }

    if (albumToDelete != null) {
        val target = albumToDelete!!
        AlertDialog(
            onDismissRequest = { albumToDelete = null },
            title = { Text("Delete Album '${target.name}'?") },
            text = { Text("Items inside this album will remain in your vault and be moved to the 'Default' album.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteAlbum(target.name)
                    albumToDelete = null
                }) {
                    Text("Delete", color = Color(0xFFFF5252))
                }
            },
            dismissButton = {
                TextButton(onClick = { albumToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
