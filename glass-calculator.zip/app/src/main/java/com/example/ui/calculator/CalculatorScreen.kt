package com.example.ui.calculator

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassIconButton
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun CalculatorScreen(
    viewModel: CalculatorViewModel,
    onTriggerBiometric: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val theme = LiquidGlassTheme.colors
    val context = LocalContext.current

    fun performHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(20)
            }
        } catch (_: Exception) {}
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(theme.backgroundBrush)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header: Calculator title & Biometric Quick Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(theme.accentPrimary)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Calculator",
                        color = theme.textSecondary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (uiState.isBiometricEnabled) {
                    GlassIconButton(
                        icon = Icons.Default.Fingerprint,
                        onClick = {
                            performHaptic()
                            onTriggerBiometric()
                        },
                        tint = theme.accentPrimary,
                        size = 40.dp,
                        contentDescription = "Biometric Unlock",
                        testTag = "calculator_biometric_btn"
                    )
                }
            }

            // PIN Setup Prompt Banner (if first launch)
            AnimatedVisibility(
                visible = uiState.setupPromptMessage != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                uiState.setupPromptMessage?.let { msg ->
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        backgroundColor = theme.accentPrimary.copy(alpha = 0.12f),
                        borderBrush = Brush.horizontalGradient(
                            listOf(theme.accentPrimary.copy(0.6f), theme.accentSecondary.copy(0.6f))
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = theme.accentPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = msg,
                                color = theme.textPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Display Screen Section
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .padding(bottom = 12.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Bottom
            ) {
                if (uiState.expressionText.isNotEmpty()) {
                    Text(
                        text = uiState.expressionText,
                        color = theme.textSecondary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.End,
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 4.dp)
                    )
                }

                val displayText = uiState.displayText
                val fontSize = when {
                    displayText.length > 12 -> 34.sp
                    displayText.length > 8 -> 44.sp
                    else -> 56.sp
                }

                Text(
                    text = displayText,
                    color = theme.textPrimary,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Light,
                    textAlign = TextAlign.End,
                    maxLines = 1,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("calculator_display_text")
                )
            }

            // Keypad Grid (4 columns x 5 rows)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Row 1: AC, +/-, %, ÷
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CalcKey(
                        text = "AC",
                        modifier = Modifier.weight(1f),
                        type = KeyType.ACTION,
                        onClick = { performHaptic(); viewModel.onClear() },
                        testTag = "calc_key_ac"
                    )
                    CalcKey(
                        text = "+/-",
                        modifier = Modifier.weight(1f),
                        type = KeyType.ACTION,
                        onClick = { performHaptic(); viewModel.onToggleSign() },
                        testTag = "calc_key_sign"
                    )
                    CalcKey(
                        text = "%",
                        modifier = Modifier.weight(1f),
                        type = KeyType.ACTION,
                        onClick = { performHaptic(); viewModel.onPercentage() },
                        testTag = "calc_key_percent"
                    )
                    CalcKey(
                        text = "÷",
                        modifier = Modifier.weight(1f),
                        type = KeyType.OPERATOR,
                        onClick = { performHaptic(); viewModel.onOperator("÷") },
                        testTag = "calc_key_div"
                    )
                }

                // Row 2: 7, 8, 9, ×
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CalcKey(
                        text = "7",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("7") },
                        testTag = "calc_key_7"
                    )
                    CalcKey(
                        text = "8",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("8") },
                        testTag = "calc_key_8"
                    )
                    CalcKey(
                        text = "9",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("9") },
                        testTag = "calc_key_9"
                    )
                    CalcKey(
                        text = "×",
                        modifier = Modifier.weight(1f),
                        type = KeyType.OPERATOR,
                        onClick = { performHaptic(); viewModel.onOperator("×") },
                        testTag = "calc_key_mul"
                    )
                }

                // Row 3: 4, 5, 6, -
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CalcKey(
                        text = "4",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("4") },
                        testTag = "calc_key_4"
                    )
                    CalcKey(
                        text = "5",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("5") },
                        testTag = "calc_key_5"
                    )
                    CalcKey(
                        text = "6",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("6") },
                        testTag = "calc_key_6"
                    )
                    CalcKey(
                        text = "-",
                        modifier = Modifier.weight(1f),
                        type = KeyType.OPERATOR,
                        onClick = { performHaptic(); viewModel.onOperator("-") },
                        testTag = "calc_key_sub"
                    )
                }

                // Row 4: 1, 2, 3, +
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CalcKey(
                        text = "1",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("1") },
                        testTag = "calc_key_1"
                    )
                    CalcKey(
                        text = "2",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("2") },
                        testTag = "calc_key_2"
                    )
                    CalcKey(
                        text = "3",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("3") },
                        testTag = "calc_key_3"
                    )
                    CalcKey(
                        text = "+",
                        modifier = Modifier.weight(1f),
                        type = KeyType.OPERATOR,
                        onClick = { performHaptic(); viewModel.onOperator("+") },
                        testTag = "calc_key_add"
                    )
                }

                // Row 5: 0, ., ⌫, =
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CalcKey(
                        text = "0",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDigit("0") },
                        testTag = "calc_key_0"
                    )
                    CalcKey(
                        text = ".",
                        modifier = Modifier.weight(1f),
                        type = KeyType.NUMBER,
                        onClick = { performHaptic(); viewModel.onDecimal() },
                        testTag = "calc_key_dot"
                    )
                    CalcKey(
                        icon = Icons.Default.Backspace,
                        modifier = Modifier.weight(1f),
                        type = KeyType.ACTION,
                        onClick = { performHaptic(); viewModel.onBackspace() },
                        testTag = "calc_key_backspace"
                    )
                    CalcKey(
                        text = "=",
                        modifier = Modifier.weight(1f),
                        type = KeyType.EQUALS,
                        onClick = { performHaptic(); viewModel.onEquals() },
                        testTag = "calc_key_equals"
                    )
                }
            }
        }
    }
}

enum class KeyType {
    NUMBER,
    OPERATOR,
    ACTION,
    EQUALS
}

@Composable
fun CalcKey(
    modifier: Modifier = Modifier,
    text: String? = null,
    icon: ImageVector? = null,
    type: KeyType = KeyType.NUMBER,
    onClick: () -> Unit,
    testTag: String = "calc_key"
) {
    val theme = LiquidGlassTheme.colors
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1f,
        animationSpec = tween(durationMillis = 80),
        label = "key_scale"
    )

    val shape = RoundedCornerShape(22.dp)

    val bgBrush = when (type) {
        KeyType.EQUALS -> theme.keyEqualsBrush
        else -> null
    }

    val bgColor = when (type) {
        KeyType.EQUALS -> Color.Transparent
        KeyType.NUMBER -> theme.keyNumberBg
        KeyType.OPERATOR -> theme.keyOperatorBg
        KeyType.ACTION -> theme.keyActionBg
    }

    val textColor = when (type) {
        KeyType.EQUALS -> Color.White
        KeyType.OPERATOR -> theme.accentPrimary
        KeyType.ACTION -> theme.accentSecondary
        KeyType.NUMBER -> theme.textPrimary
    }

    val border = when (type) {
        KeyType.EQUALS -> Brush.linearGradient(listOf(Color.White.copy(0.6f), Color.Transparent))
        KeyType.OPERATOR -> Brush.linearGradient(listOf(theme.accentPrimary.copy(0.4f), Color.Transparent))
        else -> theme.glassBorderSubtle
    }

    Box(
        modifier = modifier
            .height(68.dp)
            .scale(scale)
            .clip(shape)
            .then(
                if (bgBrush != null) Modifier.background(bgBrush)
                else Modifier.background(bgColor)
            )
            .border(1.dp, border, shape)
            .drawBehind {
                // Subtle top specular highlight reflection
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = if (type == KeyType.EQUALS) 0.4f else 0.12f),
                            Color.Transparent
                        )
                    ),
                    start = Offset(size.width * 0.15f, 1f),
                    end = Offset(size.width * 0.85f, 1f),
                    strokeWidth = 2f
                )
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        if (text != null) {
            Text(
                text = text,
                color = textColor,
                fontSize = if (type == KeyType.OPERATOR || type == KeyType.EQUALS) 28.sp else 24.sp,
                fontWeight = if (type == KeyType.EQUALS) FontWeight.Bold else FontWeight.Medium
            )
        } else if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = "Backspace",
                tint = textColor,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
