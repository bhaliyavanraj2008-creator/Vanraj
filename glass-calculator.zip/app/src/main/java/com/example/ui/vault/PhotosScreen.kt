package com.example.ui.vault

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MediaType
import com.example.data.VaultItem
import com.example.data.VaultRepository
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassIconButton
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun PhotosScreen(
    viewModel: VaultViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val allPhotos by viewModel.photos.collectAsState()
    val allAlbums by viewModel.albums.collectAsState()
    val theme = LiquidGlassTheme.colors

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importMediaUris(uris, MediaType.PHOTO)
        }
    }

    val filteredPhotos = if (uiState.selectedAlbumFilter == "All") {
        allPhotos
    } else {
        allPhotos.filter { it.album == uiState.selectedAlbumFilter }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("photos_screen")
    ) {
        // Multi-selection Action Bar
        AnimatedVisibility(visible = uiState.isMultiSelectMode) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(theme.glassSurfaceElevated)
                    .border(1.dp, theme.accentPrimary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlassIconButton(
                        icon = Icons.Default.Close,
                        onClick = { viewModel.clearSelection() },
                        size = 36.dp,
                        tint = theme.textSecondary,
                        contentDescription = "Cancel Selection"
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${uiState.selectedItemIds.size} selected",
                        color = theme.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlassIconButton(
                        icon = Icons.Default.DriveFileMove,
                        onClick = { viewModel.setShowMoveAlbumDialog(true) },
                        size = 36.dp,
                        tint = theme.accentPrimary,
                        contentDescription = "Move to Album"
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    GlassIconButton(
                        icon = Icons.Default.Share,
                        onClick = { viewModel.exportSelectedItems(allPhotos) },
                        size = 36.dp,
                        tint = theme.accentSecondary,
                        contentDescription = "Export Selected"
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    GlassIconButton(
                        icon = Icons.Default.Delete,
                        onClick = { viewModel.deleteSelectedItems(allPhotos) },
                        size = 36.dp,
                        tint = Color(0xFFFF5252),
                        contentDescription = "Delete Selected"
                    )
                }
            }
        }

        // Album Filter Chips Row
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = uiState.selectedAlbumFilter == "All",
                    onClick = { viewModel.setAlbumFilter("All") },
                    label = { Text("All (${allPhotos.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = theme.accentPrimary.copy(0.2f),
                        selectedLabelColor = theme.accentPrimary,
                        containerColor = theme.glassSurface,
                        labelColor = theme.textSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = uiState.selectedAlbumFilter == "All",
                        borderColor = if (uiState.selectedAlbumFilter == "All") theme.accentPrimary else Color.Transparent
                    )
                )
            }

            items(allAlbums) { album ->
                val count = allPhotos.count { it.album == album.name }
                FilterChip(
                    selected = uiState.selectedAlbumFilter == album.name,
                    onClick = { viewModel.setAlbumFilter(album.name) },
                    label = { Text("${album.name} ($count)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = theme.accentPrimary.copy(0.2f),
                        selectedLabelColor = theme.accentPrimary,
                        containerColor = theme.glassSurface,
                        labelColor = theme.textSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = uiState.selectedAlbumFilter == album.name,
                        borderColor = if (uiState.selectedAlbumFilter == album.name) theme.accentPrimary else Color.Transparent
                    )
                )
            }
        }

        // Photos Grid or Empty State
        if (filteredPhotos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(theme.glassSurfaceElevated)
                            .border(1.dp, theme.glassBorderSubtle, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = null,
                            tint = theme.accentPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No private photos yet",
                        color = theme.textPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Import photos to encrypt with AES-256 and protect them behind your calculator PIN.",
                        color = theme.textSecondary,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    GlassButton(
                        text = "Import Photos",
                        icon = Icons.Default.AddPhotoAlternate,
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        testTag = "import_photos_empty_btn"
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 108.dp),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredPhotos, key = { it.id }) { photo ->
                    PhotoGridItem(
                        item = photo,
                        repository = viewModel.repository,
                        isSelected = uiState.selectedItemIds.contains(photo.id),
                        isMultiSelect = uiState.isMultiSelectMode,
                        onSelectToggle = { viewModel.toggleSelection(photo.id) },
                        onClick = {
                            if (uiState.isMultiSelectMode) {
                                viewModel.toggleSelection(photo.id)
                            } else {
                                viewModel.openPhotoDetail(photo)
                            }
                        }
                    )
                }
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun PhotoGridItem(
    item: VaultItem,
    repository: VaultRepository,
    isSelected: Boolean,
    isMultiSelect: Boolean,
    onSelectToggle: () -> Unit,
    onClick: () -> Unit
) {
    val theme = LiquidGlassTheme.colors

    val thumbnailBitmap by produceState<Bitmap?>(initialValue = null, key1 = item.id) {
        value = repository.loadThumbnail(item)
    }

    val itemBorder: Brush = if (isSelected) androidx.compose.ui.graphics.SolidColor(theme.accentPrimary) else theme.glassBorderSubtle

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(14.dp))
            .border(
                if (isSelected) 2.dp else 1.dp,
                itemBorder,
                RoundedCornerShape(14.dp)
            )
            .background(theme.glassSurface)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onSelectToggle
            )
            .testTag("photo_grid_item_${item.id}"),
        contentAlignment = Alignment.Center
    ) {
        if (thumbnailBitmap != null) {
            Image(
                bitmap = thumbnailBitmap!!.asImageBitmap(),
                contentDescription = item.displayName,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = theme.textSecondary.copy(alpha = 0.4f),
                modifier = Modifier.size(24.dp)
            )
        }

        // Selection Checkmark Badge
        if (isSelected || isMultiSelect) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) theme.accentPrimary else Color(0x66000000))
                    .border(1.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = if (theme.isDark) Color(0xFF090D16) else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
