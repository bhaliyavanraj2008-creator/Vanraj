package com.example.security

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class PinManager(context: Context) {

    private val prefs = context.getSharedPreferences("glass_vault_security_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
        private const val KEY_AUTO_LOCK_TIMEOUT = "auto_lock_timeout"
        private const val KEY_THEME = "app_theme"
        private const val KEY_ICON_HIDDEN = "app_icon_hidden"
        private const val ITERATIONS = 12000
        private const val KEY_LENGTH = 256
    }

    fun isPinSet(): Boolean {
        return prefs.contains(KEY_PIN_HASH) && prefs.contains(KEY_PIN_SALT)
    }

    fun setPin(pin: String) {
        val random = SecureRandom()
        val salt = ByteArray(16)
        random.nextBytes(salt)
        val hash = hashPin(pin, salt)

        prefs.edit()
            .putString(KEY_PIN_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .putString(KEY_PIN_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .apply()
    }

    fun verifyPin(pin: String): Boolean {
        val savedHashStr = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val savedSaltStr = prefs.getString(KEY_PIN_SALT, null) ?: return false

        val salt = Base64.decode(savedSaltStr, Base64.NO_WRAP)
        val expectedHash = Base64.decode(savedHashStr, Base64.NO_WRAP)
        val actualHash = hashPin(pin, salt)

        if (expectedHash.size != actualHash.size) return false
        var diff = 0
        for (i in expectedHash.indices) {
            diff = diff or (expectedHash[i].toInt() xor actualHash[i].toInt())
        }
        return diff == 0
    }

    private fun hashPin(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    fun isBiometricEnabled(): Boolean {
        return prefs.getBoolean(KEY_BIOMETRIC_ENABLED, false)
    }

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
    }

    fun getAutoLockTimeoutMs(): Long {
        // Default: 0L = Immediately lock on background
        return prefs.getLong(KEY_AUTO_LOCK_TIMEOUT, 0L)
    }

    fun setAutoLockTimeoutMs(timeoutMs: Long) {
        prefs.edit().putLong(KEY_AUTO_LOCK_TIMEOUT, timeoutMs).apply()
    }

    fun getSelectedTheme(): String {
        return prefs.getString(KEY_THEME, "obsidian_cyan") ?: "obsidian_cyan"
    }

    fun setSelectedTheme(themeId: String) {
        prefs.edit().putString(KEY_THEME, themeId).apply()
    }

    fun isAppIconHidden(): Boolean {
        return prefs.getBoolean(KEY_ICON_HIDDEN, false)
    }

    fun setAppIconHidden(hidden: Boolean) {
        prefs.edit().putBoolean(KEY_ICON_HIDDEN, hidden).apply()
    }
}
