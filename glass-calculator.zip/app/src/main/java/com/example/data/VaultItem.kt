package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

enum class MediaType {
    PHOTO,
    VIDEO
}

class Converters {
    @TypeConverter
    fun fromMediaType(value: MediaType): String = value.name

    @TypeConverter
    fun toMediaType(value: String): MediaType = MediaType.valueOf(value)
}

@Entity(tableName = "vault_items")
data class VaultItem(
    @PrimaryKey
    val id: String,
    val displayName: String,
    val encryptedFileName: String,
    val thumbnailFileName: String?,
    val type: MediaType,
    val album: String = "Default",
    val dateAdded: Long = System.currentTimeMillis(),
    val sizeBytes: Long = 0L,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val isFavorite: Boolean = false
)

@Entity(tableName = "vault_albums")
data class VaultAlbum(
    @PrimaryKey
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isSystem: Boolean = false
)
