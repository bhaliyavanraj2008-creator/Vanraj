package com.example.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.LruCache
import com.example.security.KeystoreHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

class VaultRepository(private val context: Context) {

    private val db = VaultDatabase.getDatabase(context)
    private val dao = db.vaultDao()

    private val mediaDir = File(context.filesDir, "vault_media").apply { if (!exists()) mkdirs() }
    private val thumbsDir = File(context.filesDir, "vault_thumbs").apply { if (!exists()) mkdirs() }
    private val streamCacheDir = File(context.cacheDir, "vault_stream").apply { if (!exists()) mkdirs() }

    // In-memory LRU cache for decrypted thumbnails (max 50 MB or 100 items)
    private val thumbnailCache = object : LruCache<String, Bitmap>(60) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return value.byteCount / 1024
        }
    }

    fun getItems(type: MediaType): Flow<List<VaultItem>> = dao.getItemsByType(type)
    fun getItemsByAlbum(type: MediaType, album: String): Flow<List<VaultItem>> = dao.getItemsByTypeAndAlbum(type, album)
    fun getAllAlbums(): Flow<List<VaultAlbum>> = dao.getAllAlbums()
    fun getTotalVaultSizeBytes(): Flow<Long?> = dao.getTotalVaultSizeBytes()
    fun getSizeByType(type: MediaType): Flow<Long?> = dao.getSizeByType(type)
    fun getCountByType(type: MediaType): Flow<Int> = dao.getCountByType(type)

    suspend fun createAlbum(name: String) = withContext(Dispatchers.IO) {
        if (name.isNotBlank()) {
            dao.insertAlbum(VaultAlbum(name = name.trim(), isSystem = false))
        }
    }

    suspend fun deleteAlbum(name: String) = withContext(Dispatchers.IO) {
        dao.deleteAlbum(name)
    }

    suspend fun moveItemToAlbum(itemId: String, albumName: String) = withContext(Dispatchers.IO) {
        dao.moveItemToAlbum(itemId, albumName)
    }

    suspend fun importMedia(uri: Uri, type: MediaType, album: String = "Default"): Result<VaultItem> = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            var displayName = if (type == MediaType.PHOTO) "IMG_${System.currentTimeMillis()}.jpg" else "VID_${System.currentTimeMillis()}.mp4"
            var fileSize = 0L

            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        val name = cursor.getString(nameIndex)
                        if (!name.isNullOrBlank()) displayName = name
                    }
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex != -1) {
                        fileSize = cursor.getLong(sizeIndex)
                    }
                }
            }

            val id = UUID.randomUUID().toString()
            val encFileName = "$id.enc"
            val encMediaFile = File(mediaDir, encFileName)

            // Encrypt and save media
            contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(encMediaFile).use { outputStream ->
                    KeystoreHelper.encryptStream(inputStream, outputStream)
                }
            } ?: return@withContext Result.failure(Exception("Unable to open media stream"))

            if (fileSize == 0L) {
                fileSize = encMediaFile.length()
            }

            // Generate thumbnail & metadata
            var thumbFileName: String? = null
            var durationMs = 0L
            var width = 0
            var height = 0

            if (type == MediaType.PHOTO) {
                // Generate photo thumbnail
                val thumbBitmap = createPhotoThumbnail(uri)
                if (thumbBitmap != null) {
                    width = thumbBitmap.width
                    height = thumbBitmap.height
                    thumbFileName = "$id.thumb.enc"
                    saveEncryptedThumbnail(thumbBitmap, File(thumbsDir, thumbFileName))
                    thumbnailCache.put(id, thumbBitmap)
                }
            } else {
                // Generate video thumbnail & duration
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uri)
                    val frameBitmap = retriever.getFrameAtTime(1000000) ?: retriever.frameAtTime
                    val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    durationMs = durationStr?.toLongOrNull() ?: 0L
                    val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    width = widthStr?.toIntOrNull() ?: 0
                    height = heightStr?.toIntOrNull() ?: 0

                    if (frameBitmap != null) {
                        val scaled = Bitmap.createScaledBitmap(frameBitmap, 320, (320f * (frameBitmap.height.toFloat() / frameBitmap.width.coerceAtLeast(1))).toInt().coerceAtLeast(1), true)
                        thumbFileName = "$id.thumb.enc"
                        saveEncryptedThumbnail(scaled, File(thumbsDir, thumbFileName))
                        thumbnailCache.put(id, scaled)
                    }
                } catch (e: Exception) {
                    // Fallback
                } finally {
                    try { retriever.release() } catch (_: Exception) {}
                }
            }

            val item = VaultItem(
                id = id,
                displayName = displayName,
                encryptedFileName = encFileName,
                thumbnailFileName = thumbFileName,
                type = type,
                album = album,
                dateAdded = System.currentTimeMillis(),
                sizeBytes = fileSize,
                durationMs = durationMs,
                width = width,
                height = height
            )

            dao.insertItem(item)
            Result.success(item)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun createPhotoThumbnail(uri: Uri): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }
            val sampleSize = calculateInSampleSize(options, 320, 320)
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height: Int, width: Int) = options.run { outHeight to outWidth }
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    private fun saveEncryptedThumbnail(bitmap: Bitmap, targetFile: File) {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 75, baos)
        val plainBytes = baos.toByteArray()
        val encryptedBytes = KeystoreHelper.encryptBytes(plainBytes)
        FileOutputStream(targetFile).use { it.write(encryptedBytes) }
    }

    suspend fun loadThumbnail(item: VaultItem): Bitmap? = withContext(Dispatchers.IO) {
        thumbnailCache.get(item.id)?.let { return@withContext it }
        val thumbFile = item.thumbnailFileName?.let { File(thumbsDir, it) }
        if (thumbFile != null && thumbFile.exists()) {
            try {
                val encBytes = thumbFile.readBytes()
                val decBytes = KeystoreHelper.decryptBytes(encBytes)
                val bitmap = BitmapFactory.decodeByteArray(decBytes, 0, decBytes.size)
                if (bitmap != null) {
                    thumbnailCache.put(item.id, bitmap)
                    return@withContext bitmap
                }
            } catch (e: Exception) {
                // Decryption error or corrupt
            }
        }
        null
    }

    suspend fun decryptPhotoToBitmap(item: VaultItem): Bitmap? = withContext(Dispatchers.IO) {
        val encFile = File(mediaDir, item.encryptedFileName)
        if (!encFile.exists()) return@withContext null
        try {
            val baos = ByteArrayOutputStream()
            FileInputStream(encFile).use { fis ->
                KeystoreHelper.decryptStream(fis, baos)
            }
            val bytes = baos.toByteArray()
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun prepareVideoForPlayback(item: VaultItem): File? = withContext(Dispatchers.IO) {
        val encFile = File(mediaDir, item.encryptedFileName)
        if (!encFile.exists()) return@withContext null
        try {
            // Decrypt to private cache file
            val tempFile = File(streamCacheDir, "${item.id}_temp.mp4")
            if (tempFile.exists() && tempFile.length() > 0) return@withContext tempFile

            FileInputStream(encFile).use { fis ->
                FileOutputStream(tempFile).use { fos ->
                    KeystoreHelper.decryptStream(fis, fos)
                }
            }
            tempFile
        } catch (e: Exception) {
            null
        }
    }

    fun clearPlaybackCache() {
        try {
            streamCacheDir.listFiles()?.forEach { it.delete() }
        } catch (_: Exception) {}
    }

    suspend fun exportToGallery(item: VaultItem): Result<Uri> = withContext(Dispatchers.IO) {
        val encFile = File(mediaDir, item.encryptedFileName)
        if (!encFile.exists()) return@withContext Result.failure(Exception("Encrypted file not found"))

        try {
            val resolver = context.contentResolver
            val collection = if (item.type == MediaType.PHOTO) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                }
            }

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, item.displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, if (item.type == MediaType.PHOTO) "image/jpeg" else "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val relativePath = if (item.type == MediaType.PHOTO) {
                        Environment.DIRECTORY_PICTURES + "/GlassVault"
                    } else {
                        Environment.DIRECTORY_MOVIES + "/GlassVault"
                    }
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }

            val outUri = resolver.insert(collection, values) ?: return@withContext Result.failure(Exception("Failed to create MediaStore entry"))

            resolver.openOutputStream(outUri)?.use { outputStream ->
                FileInputStream(encFile).use { inputStream ->
                    KeystoreHelper.decryptStream(inputStream, outputStream)
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(outUri, values, null, null)
            }

            Result.success(outUri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteItem(item: VaultItem) = withContext(Dispatchers.IO) {
        val encFile = File(mediaDir, item.encryptedFileName)
        if (encFile.exists()) encFile.delete()

        item.thumbnailFileName?.let {
            val thumb = File(thumbsDir, it)
            if (thumb.exists()) thumb.delete()
        }
        thumbnailCache.remove(item.id)

        val tempVid = File(streamCacheDir, "${item.id}_temp.mp4")
        if (tempVid.exists()) tempVid.delete()

        dao.deleteItem(item)
    }

    fun getDeviceFreeSpace(): Long {
        return try {
            val stat = StatFs(context.filesDir.path)
            stat.availableBlocksLong * stat.blockSizeLong
        } catch (e: Exception) {
            0L
        }
    }

    fun clearAllCaches() {
        thumbnailCache.evictAll()
        clearPlaybackCache()
    }
}
