package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultDao {

    @Query("SELECT * FROM vault_items WHERE type = :type ORDER BY dateAdded DESC")
    fun getItemsByType(type: MediaType): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE type = :type AND album = :album ORDER BY dateAdded DESC")
    fun getItemsByTypeAndAlbum(type: MediaType, album: String): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items ORDER BY dateAdded DESC")
    fun getAllItems(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: String): VaultItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: VaultItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<VaultItem>)

    @Update
    suspend fun updateItem(item: VaultItem)

    @Delete
    suspend fun deleteItem(item: VaultItem)

    @Query("DELETE FROM vault_items WHERE id = :id")
    suspend fun deleteItemById(id: String)

    @Query("UPDATE vault_items SET album = :newAlbum WHERE id = :id")
    suspend fun moveItemToAlbum(id: String, newAlbum: String)

    @Query("SELECT * FROM vault_albums ORDER BY createdAt ASC")
    fun getAllAlbums(): Flow<List<VaultAlbum>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAlbum(album: VaultAlbum)

    @Query("DELETE FROM vault_albums WHERE name = :name AND isSystem = 0")
    suspend fun deleteAlbum(name: String)

    @Query("SELECT SUM(sizeBytes) FROM vault_items")
    fun getTotalVaultSizeBytes(): Flow<Long?>

    @Query("SELECT SUM(sizeBytes) FROM vault_items WHERE type = :type")
    fun getSizeByType(type: MediaType): Flow<Long?>

    @Query("SELECT COUNT(*) FROM vault_items WHERE type = :type")
    fun getCountByType(type: MediaType): Flow<Int>
}
