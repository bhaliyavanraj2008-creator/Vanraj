package com.example

import android.app.Application
import android.content.Context

class GlassVaultApplication : Application() {

    companion object {
        lateinit var instance: GlassVaultApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}
