package com.example

import android.os.Bundle
import android.os.SystemClock
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import com.example.security.BiometricHelper
import com.example.ui.calculator.CalculatorScreen
import com.example.ui.calculator.CalculatorViewModel
import com.example.ui.theme.LiquidGlassAppTheme
import com.example.ui.vault.VaultHomeScreen
import com.example.ui.vault.VaultViewModel

class MainActivity : FragmentActivity() {

    private val calculatorViewModel: CalculatorViewModel by viewModels()
    private val vaultViewModel: VaultViewModel by viewModels()

    private var backgroundTimestamp: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val calcUiState by calculatorViewModel.uiState.collectAsState()
            val vaultUiState by vaultViewModel.uiState.collectAsState()

            LaunchedEffect(Unit) {
                calculatorViewModel.refreshState()
            }

            LiquidGlassAppTheme(themeId = vaultUiState.currentThemeId) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AnimatedContent(
                        targetState = calcUiState.isUnlocked,
                        transitionSpec = {
                            if (targetState) {
                                (slideInVertically { height -> height } + fadeIn())
                                    .togetherWith(slideOutVertically { height -> -height } + fadeOut())
                            } else {
                                (slideInVertically { height -> -height } + fadeIn())
                                    .togetherWith(slideOutVertically { height -> height } + fadeOut())
                            }
                        },
                        label = "vault_unlock_transition"
                    ) { isUnlocked ->
                        if (isUnlocked) {
                            VaultHomeScreen(
                                viewModel = vaultViewModel,
                                onLockVault = {
                                    calculatorViewModel.lockVault()
                                    vaultViewModel.onAppBackgrounded()
                                }
                            )
                        } else {
                            CalculatorScreen(
                                viewModel = calculatorViewModel,
                                onTriggerBiometric = { promptBiometric() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val calcState = calculatorViewModel.uiState.value
        if (calcState.isUnlocked && backgroundTimestamp > 0L) {
            val timeout = calculatorViewModel.pinManager.getAutoLockTimeoutMs()
            val elapsed = SystemClock.elapsedRealtime() - backgroundTimestamp
            if (elapsed >= timeout) {
                calculatorViewModel.lockVault()
                vaultViewModel.onAppBackgrounded()
            }
        }
        backgroundTimestamp = 0L
    }

    override fun onPause() {
        super.onPause()
        backgroundTimestamp = SystemClock.elapsedRealtime()
        val timeout = calculatorViewModel.pinManager.getAutoLockTimeoutMs()
        if (timeout == 0L && calculatorViewModel.uiState.value.isUnlocked) {
            calculatorViewModel.lockVault()
            vaultViewModel.onAppBackgrounded()
        }
    }

    private fun promptBiometric() {
        if (!BiometricHelper.isBiometricAvailable(this)) return
        BiometricHelper.showBiometricPrompt(
            activity = this,
            title = getString(R.string.biometric_prompt_title),
            subtitle = getString(R.string.biometric_prompt_subtitle),
            negativeButtonText = getString(R.string.biometric_prompt_negative),
            onSuccess = {
                calculatorViewModel.triggerUnlock()
            },
            onError = {
                // User can continue with secret PIN in calculator
            }
        )
    }
}
